import { useState } from 'react'
import './App.css'

function App() {

  return (
    <>
        <section className="posts">

        </section>
        <section className="add-post">

        </section>
    </>
  )
}

export default App
